<?php
$uploaddir = '/opt/lampp/htdocs/CC/image';
$uploadfile = $uploaddir . basename($_FILES['image']['name']);
if(isset($_POST["submit"])){
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false){
       $image = $_FILES['image']['name'];
        $imgContent = addslashes(file_get_contents($image));

        /*
         * Insert image data into database
         */
        
        //DB details
        $dbHost     = 'localhost';
        $dbUsername = 'root';
        $dbPassword = '';
        $dbName     = 'image';
        
        //Create connection and select DB
        $db = mysqli_connect($dbHost, $dbUsername, $dbPassword);
        mysqli_select_db($db,$dbName);
        
        // Check connection
        if($db->connect_error){
            die("Connection failed: " . $db->connect_error);
        }
        
        $dataTime = date("Y-m-d H:i:s");
        echo $dataTime ;
        
        //Insert image content into database
        $qry="INSERT into images (image, created) VALUES ('$imgContent', '$dataTime')";
        $insert = $db->query($qry);
        if($insert){
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
    }
    else{
        echo "Please select an image file to upload.";
    }

}
?>